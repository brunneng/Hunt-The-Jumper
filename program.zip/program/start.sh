#!/bin/sh
java -Djava.library.path=lib -Dorg.lwjgl.util.Debug=true -jar HuntTheJumper-0.1.jar
pause